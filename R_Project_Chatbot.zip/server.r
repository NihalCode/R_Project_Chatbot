# server.R
library(plumber)

# Create and run the API
run_api <- function() {
  pr <- plumb("C://Users//nihal//Downloads//api_2.R")  # Make sure this path is correct
  pr$run(port = 8000)
}

# Run the server
run_api()
